package com.mycompany.mavenproject16;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CalculadoraTest {

    Calculadora calculadora = new Calculadora();

    @Test
    public void testSuma() {
        assertEquals(5, calculadora.suma(2, 3));
    }

    @Test
    public void testResta() {
        assertEquals(1, calculadora.resta(3, 2));
    }

    @Test
    public void testMultiplicacio() {
        assertEquals(6, calculadora.multiplicacio(2, 3));
    }

    @Test
    public void testDivisio() {
        assertEquals(2, calculadora.divisio(6, 3));
    }
@Test
public void testDivisioPerZero() {
    // Esto verifica que realmente se lance la excepción cuando b es 0
    assertThrows(IllegalArgumentException.class, () -> {
        calculadora.divisio(10, 0);
    });
}
    @Test
    public void testDivisio10Entre2() {
        assertEquals(5, calculadora.divisio(10, 2));
    }

    @Test
    public void testSumaNegatius() {
        assertEquals(-5, calculadora.suma(-2, -3));
    }
}
