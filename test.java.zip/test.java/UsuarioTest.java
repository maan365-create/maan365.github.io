import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.mycompany.vib.Usuario;

/**
 *
 * @author gporto
 */
public class UsuarioTest {
    
    // 1 Test: crear usuario
    @Test
    void crearUsuarioValido() {
        Usuario u = new Usuario("Ana", 25);

        assertEquals("Ana", u.getNombre());
        assertEquals(25, u.getEdad());
        assertTrue(u.isActivo());
    }

    // 2 Test: usuario activo por defecto
    @Test
    void usuarioNuevoEstaActivo() {
        Usuario u = new Usuario("Luis", 30);

        assertTrue(u.isActivo());
    }

    // 3 ️Test: desactivar usuario
    @Test
    void desactivarUsuarioCambiaEstado() {
        Usuario u = new Usuario("Maria", 40);
        u.desactivar();

        assertFalse(u.isActivo());
    }

    // 4 mayor de edad
    @Test
    void usuarioMayorDeEdad() {
        Usuario u = new Usuario("Pedro", 18);

        assertTrue(u.esMayorDeEdad());
    }

    // 5 menor de edad
    @Test
    void usuarioMenorDeEdad() {
        Usuario u = new Usuario("Laura", 17);

        assertFalse(u.esMayorDeEdad());
    }

    // 6 nombre vacío lanza excepción
    // assertThrows -> Este código debe lanzar esta excepción. Si no la lanza, el test falla.”
    @Test
    void nombreVacioLanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Usuario("", 20);
        });
    }

    // 7 nombre null lanza excepción
    @Test
    void nombreNullLanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Usuario(null, 20);
        });
    }

    // 8 edad negativa lanza excepción
    @Test
    void edadNegativaLanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Usuario("Carlos", -1);
        });
    }
    
}